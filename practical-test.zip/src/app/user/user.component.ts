import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  prof = [];
  constructor(private authServ: AuthService, private router: Router) { }

  ngOnInit() {
    this.authServ.getProfiles().subscribe(resData => {
      console.log(resData.items)
      this.prof = resData.items;
    });
  }

  filter(data: string) {
    if (data) {
      this.authServ.serchProf(data).subscribe(resData => {
        this.prof = resData.items;
      })
    } else {
      this.authServ.getProfiles().subscribe(resData => {
        console.log(resData.items)
        this.prof = resData.items;
      });
    }
  }
  onClick(d) {
    this.authServ.userData.next(d);
    this.router.navigate(['/user/profile']);
  }


}
