import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router, private authServ: AuthService) { }

  ngOnInit() {
    this.authServ.user.subscribe(user => {
      if(user === 'admin'){
        this.router.navigate(['/admin']);
      }else if(user === 'user'){
        this.router.navigate(['/user']);
      }
    })
  }

  redi(data){
    if(data){
      this.authServ.authent(data);
    }
  }

}
