import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  user = new BehaviorSubject<string>(null);
  userData = new BehaviorSubject<{}>(null);

  constructor(private http: HttpClient) { }

  authent(data: string) {
    this.user.next(data);
  }

  getProfiles() {
    return this.http.get<any>("https://api.github.com/search/users?q=eric");
  }
  serchProf(data: string) {
    return this.http.get<any>("https://api.github.com/search/users?q=" + data);
  }
}
